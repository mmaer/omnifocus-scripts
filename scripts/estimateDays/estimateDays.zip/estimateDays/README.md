# Estimate days

[Install plugin](omnifocus:///omnijs-install?path=https://github.com/mmaer/omnifocus-scripts/raw/update_readme/scripts/estimateDays/estimateDays.zip)

Select a predefined date range or select your ones to get an estimated time in the given date range.

Alert displays estimated time and left time to estimate, split into morning afternoon, and evening parts of the day.

## In the future

- [ ] Add this month's predefined date option
- [ ] Add next month's predefined date option
- [ ] Estimate morning, afternoon and evening each day
