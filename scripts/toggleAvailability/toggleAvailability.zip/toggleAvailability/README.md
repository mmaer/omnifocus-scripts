# Toggle availability

Toggle the "availability" rule from "Available" to "Remaining" and vice versa in a custom perspective by running the plug-in.

[Install plug-in](omnifocus:///omnijs-install?path=https://github.com/mmaer/omnifocus-scripts/raw/main/scripts/toggleAvailability/toggleAvailability.zip)\
[Plug-In code](https://github.com/mmaer/omnifocus-scripts/blob/main/scripts/toggleAvailability/toggleAvailability.omnifocusjs)

## In the future

- [ ] Add settings in which you can define from which state to which one you want to switch. 
