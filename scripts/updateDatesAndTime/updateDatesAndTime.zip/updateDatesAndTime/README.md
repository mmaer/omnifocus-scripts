# Update Dates and Time

[Install plugin](omnifocus:///omnijs-install?path=https://github.com/mmaer/omnifocus-scripts/raw/update_readme/scripts/updateDatesAndTime/updateDatesAndTime.omnifocusjs.zip)
