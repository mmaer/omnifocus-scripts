# Left time today

[Install plugin](omnifocus:///omnijs-install?path=https://github.com/mmaer/omnifocus-scripts/raw/main/scripts/leftTimeToday/leftTimeToday.zip)\
[Plug-In code](https://github.com/mmaer/omnifocus-scripts/blob/main/scripts/leftTimeToday/leftTimeToday.omnifocusjs)

Get information about how much time is left today.

## In the future

- [ ] Display how much each selected tag is estimated
