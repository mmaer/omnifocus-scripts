# Estimate Time

[Install plugin](omnifocus:///omnijs-install?path=https://github.com/mmaer/omnifocus-scripts/raw/main/scripts/estimateTime/estimateTime.zip)\
[Plug-In code](https://github.com/mmaer/omnifocus-scripts/blob/main/scripts/estimateTime/estimateTime.omnifocusjs)

Estimate all selected tasks and projects.

## In the future

- [ ] Display how much each selected tag is estimated
