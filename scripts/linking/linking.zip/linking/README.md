# Linking

[Install plugin](omnifocus:///omnijs-install?path=https://github.com/mmaer/omnifocus-scripts/raw/update_readme/scripts/linking/linking.omnifocusjs.zip)

Plug-in links one another task by adding URLs in note.

## How to use
1. Select one or more tasks or projects.
2. Run the plug-in.
3. In each note task or project should be added a link to the rest tasks or projects.

PS: When you select only one task, the url is copied to clipboard.

## In the future

- [ ] Add only link to note
- [ ] Add url link with tag
