# Toggle duration

Toggle the "has an estimated duration" rule in a custom perspective by just running the plug-in.

[Install plug-in](omnifocus:///omnijs-install?path=https://github.com/mmaer/omnifocus-scripts/raw/main/scripts/toggleDuration/toggleDuration.zip)\
[Plug-In code](https://github.com/mmaer/omnifocus-scripts/blob/main/scripts/toggleDuration/toggleDuration.omnifocusjs)
